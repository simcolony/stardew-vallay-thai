```sh
— อยากจะช่วยแปลภาษาไทย?
— หาประโยคที่เป็นภาษาอังฤษ แล้วเริ่มแปลได้เลย
```
#### วิธีการแปลและส่งคำแปล
[สอนใช้ Github ฉบับเร่งด่วน!](https://www.youtube.com/watch?v=e39kzyoK-RQ)
#### ชื่อกลาง (สำคัญมากๆ ต้องแปลตามนี้เท่านั้น)
[Stardew Valley Glossary](https://docs.google.com/spreadsheets/d/1DBdyvEI9XNAWEPpptKmIHfUj0gGdAFzyjHH9oR7U0Zc/edit?usp=sharing)
#### พูดคุยได้เกี่ยวกับการแปล
[Discord ทีมพัฒนา Mod ภาษาไทย](https://discordapp.com/invite/TkP42Xm)

| Mod update | Status |
| ------ | ------ |
| Dialogue NPCs | 100% |
| Marriage Dialogue | 100% |
| Events | 100% |
| Festivals | 100% |
| รายการ TV | 100% |
| Mail Box | 100% |
| NPCGiftTastes | 100% |
| Dialogue ทั่วไป | 100% |
| Extra Dialogue | 100% |
| Movies & MoviesReactions | 100% |
| Schedules | 100% |

#### จัดทำโดย
SORNZiLLATE, NoTSoXDream, JASON.

#### Coder & นักตัดต่อวิดีโอ
'ELL, NoTSoXDream, Shibosan.

#### นักแปลมืออาชีพ
Memee Thechoco, Pookhao23, RushingOn, Tomyamkung.

#### ทําเนียบนักแปล
Davykun, iParnRequiem, PangInFN, ProfessorHydra, Tawan, unknownwmz.

#### ทีมงานผู้ริเริ่มโปรเจค
Artdekdok, cybertorns, MiXEL.SC, NoTSoXDream, Pigter, sornzilla, superogira.

#### Beta tester
BirdBBK, Grace Manassanan, PadalPrussus, TaNGGoDZeeD.
